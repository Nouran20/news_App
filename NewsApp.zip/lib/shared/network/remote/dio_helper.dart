import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

class DioHelper
{
  static Dio dio = Dio();

  static init() => dio = Dio(
    BaseOptions(
      baseUrl: 'https://fcm.googleapis.com/',
      receiveDataWhenStatusError: true,
    ),
  );

  static Future sendNotification({
    required String token,
    required String title,
    required String message,
    String image ='',
    String type ='',
    String id ='',
  }) async
  {
    dio.options.headers =
    {
      'Content-Type':'application/json',
      'Authorization': 'key=AAAAPsi2ISM:APA91bGGjwbiuxE8HKLd6k2qrIYa4x28SX9dqtX87fyG_J9UKtUC1FrG595FWBI86qkiGCNb0u4LnEb8HkYtupvuNjYlwFr_h5gdGjK93CRAGWhs1zT3uvaJg7lYOIy-efrAX34oE8qN'
    };
    return await dio.post(
        'fcm/send',
        data: {
          "to": token,
          "notification": {
            "title": title,
            "body": message,
            "imageUrl": image,
            "sound":"default"
          },
          "android": {
            "priority": "HIGH",
            "notification": {
              "notification_priority":"PRIORTY_MAX",
              "imageUrl": image,
              "sound":"default",
              "default_sound" : true,
              "default_vibrate_timings" : true,
              "default_light_settings":true
            }
          },
          "data":{
            "type":type,
            "id":id,
            "message":title,
            "click_action":"FLUTTER_NOTIFICATION_CLICK"
          }
        },
    );
  }


}
