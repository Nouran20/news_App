abstract class ThemeStates {}

class ThemeInitialState extends ThemeStates {}

class ChangeThemeColorState extends ThemeStates {}

class ChangeThemeState extends ThemeStates {}
