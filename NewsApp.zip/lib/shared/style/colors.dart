import 'package:flutter/material.dart';


Color buttonColor = Color.fromRGBO(32, 58, 99, 1);

Color mainColor = Color.fromRGBO(2, 138, 179, 1);

final Color appLightColor = Color.fromRGBO(237, 237, 232,1);

Color appDarkColor = Color.fromRGBO(39, 38, 37, 1);

Color goldColor = Color.fromRGBO(225, 225, 58, 1);

Color silverColor = Color.fromRGBO(125, 138, 140, 1);

