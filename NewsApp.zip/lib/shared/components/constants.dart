String uId ='';
String notificationToken ='';
String notificationType = '';
String notificationId = '';
//var arabic = /[\u0600-\u06FF]/;